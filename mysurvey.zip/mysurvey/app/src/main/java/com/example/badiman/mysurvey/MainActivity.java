package com.example.badiman.mysurvey;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import java.text.CharacterIterator;
import java.text.NumberFormat;

import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import static android.R.attr.name;

/**
 * This app displays a survey to let user to answer questions.
 */

public class MainActivity extends AppCompatActivity {
    int age = 1 ;
    EditText mEdit;
    int score = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


       /**
     * This method is called when the submit button is clicked.
     */


    public void submitSurvey(View view) {
        score = 0;
        mEdit   = (EditText)findViewById(R.id.surveyName);
        String nameTyped = mEdit.getText().toString();
        String msg1 ;

        CheckBox whereCb;
        whereCb =(CheckBox) findViewById(R.id.question_checkbox1);
        if (whereCb.isChecked())
        {
            score = score + 1;
        }
        else {
            whereCb = (CheckBox) findViewById(R.id.question_checkbox2);
            if (whereCb.isChecked())
            {
                score = score + 1;
            }
            else
            {
                whereCb =(CheckBox) findViewById(R.id.question_checkbox3);
                if(whereCb.isChecked())
                {
                    score = score +1;
                }
                else
                {
                    Toast.makeText(this,"You must choose a answer,Thanks!", Toast.LENGTH_SHORT).show();
                    return;
                }
            }
        }

        RadioButton durationCb,qualityCb,stilluseCb,recommendCb;
        durationCb=(RadioButton) findViewById(R.id.duration_checkbox1);
        if (durationCb.isChecked())
        {score=score+4;}
        else {
            durationCb = (RadioButton) findViewById(R.id.duration_checkbox2);
            if (durationCb.isChecked())
            {
                score = score + 3;
            }
            else
             {
                durationCb =(RadioButton) findViewById(R.id.duration_checkbox3);
                if(durationCb.isChecked())
                {
                    score = score +2;
                }
                else
                {
                    Toast.makeText(this,"You must choose a answer,Thanks!", Toast.LENGTH_SHORT).show();
                    return;
                }
             }
           }
        qualityCb=(RadioButton) findViewById(R.id.quality_checkbox1);
        if (qualityCb.isChecked())
        {score=score+2;}
        else {
            qualityCb = (RadioButton) findViewById(R.id.quality_checkbox2);
            if (qualityCb.isChecked())
            {
                score = score + 1;
            }
                else
                {
                    qualityCb = (RadioButton) findViewById(R.id.quality_checkbox3);
                    if(qualityCb.isChecked())
                    {
                        score=score+0;
                    }
                    else
                    {
                        Toast.makeText(this,"You must choose a answer,Thanks!", Toast.LENGTH_SHORT).show();
                        return;
                    }

                }
            }

        stilluseCb=(RadioButton) findViewById(R.id.stilluse_checkbox1);
        if (stilluseCb.isChecked())
        {score=score+2;}
        else {
            stilluseCb = (RadioButton) findViewById(R.id.stilluse_checkbox2);
            if (stilluseCb.isChecked())
            {
                score = score + 1;
            }
            else
            {
                stilluseCb = (RadioButton) findViewById(R.id.stilluse_checkbox3);
                if(stilluseCb.isChecked())
                {
                    score=score+0;
                }
                else
                {
                    Toast.makeText(this,"You must choose a answer,Thanks!", Toast.LENGTH_SHORT).show();
                    return;
                }

            }


        }

        recommendCb=(RadioButton) findViewById(R.id.recommend_checkbox1);
        if (recommendCb.isChecked())
        {score=score+2;}
        else {
            recommendCb = (RadioButton) findViewById(R.id.recommend_checkbox2);
            if (recommendCb.isChecked()) {
                score = score + 1;
            }

            else
            {
                recommendCb = (RadioButton) findViewById(R.id.recommend_checkbox3);
                if(recommendCb.isChecked())
                {
                    score=score+0;
                }
                else
                {
                    Toast.makeText(this,"You must choose a answer,Thanks!", Toast.LENGTH_SHORT).show();
                    return;
                }

            }

        }

        if (score > 6)
        { msg1 = "You like this app, Thanks you !!! :-)";}
         else
        { msg1="You don't like this app, we will make it better next time:-(";}

        String surveyMessage=createOrderSummary(age, nameTyped, score, msg1);
        displayMessage(surveyMessage);
        score=0;
    }


    public void increment (View view){
        if (age ==100)
        {
            Toast.makeText(this,"You cannot have more than 100 ages",Toast.LENGTH_SHORT).show();
            return;
        }
        age= age+1;
        displayQuantity(age);
    }
    public void decrement(View view) {
        if (age ==1)
        {Toast.makeText(this,"You cannot have less than 1 ages",Toast.LENGTH_SHORT).show();
            return;
        }
        age=age-1;
        displayQuantity(age);
    }



    /**
     * This method displays the given age value on the screen.
     */


    private void displayQuantity(int number) {
        TextView quantityTextView = (TextView) findViewById(R.id.age_text_view);
        quantityTextView.setText("" + number);
    }


    private String createOrderSummary(int age, String  getname,  int score , String msg){
         return("Name:" + getname + " \nAge: " + age + "\nScore:"+ score + "\n"+ msg);
    }


    private void displayMessage(String message){

        TextView surveyTextView = (TextView) findViewById(R.id.survey_summary_text_view);
        surveyTextView.setText(message);
    }


}